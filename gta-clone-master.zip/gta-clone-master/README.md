# gta-clone
A Unity project inspired by the original Grand Theft Auto.
